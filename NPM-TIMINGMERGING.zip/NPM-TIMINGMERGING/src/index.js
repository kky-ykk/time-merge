const mergeTimeRanges = (ranges, threshold) => {
  if (!Array.isArray(ranges) || ranges.length === 0) return [];

  ranges = ranges.filter(([start, end]) => typeof start === 'number' && typeof end === 'number' && start < end);

  ranges.sort((a, b) => a[0] - b[0]);

  const merged = [];
  let [smallest, largest] = ranges[0];

  for (let i = 1; i < ranges.length; i++) {
    const [start, end] = ranges[i];

    // Merge overlapping or close ranges
    if (largest + threshold >= start) {
      largest = Math.max(largest, end);
    } else {
      merged.push([smallest, largest]);
      smallest = start;
      largest = end;
    }
  }

  merged.push([smallest, largest]);
  return merged;
};

module.exports = { mergeTimeRanges };
